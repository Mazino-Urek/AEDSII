/*
 * Nome: Diego Da Silva Ferreira
 * Matricula: 71 06 78
 *
 * Questão 1: Compile o programa abaixo e, em seguida, execute-o no terminal da
 * seguinte forma: java ArgumentoMain algoritmos
 * */

class ArgumentoMain {
	public static void main (String[] args){
		System.out.println("Primeiro parametro: " + args[0]);
		System.out.println("Numero de parametros: " + args.length);
	}
}
